tiff = imread('sophie_crp_from_orig.tif');
for lvl = 1:100
    fn = strcat('image',sprintf('%03d',lvl),'.jpg');
    imwrite(tiff,fn,'jpeg','Quality',lvl);
end
